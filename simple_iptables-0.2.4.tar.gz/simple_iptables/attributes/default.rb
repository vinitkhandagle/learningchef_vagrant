default["simple_iptables"]["rules"] = []
default["simple_iptables"]["chains"] = []
default["simple_iptables"]["policy"] = {}
